package org.anudip.thread;

public class GenDemoApp {

	public static void main(String[] args) {
		MyDemo md1=new MyDemo("India");
		MyDemo md2=new MyDemo("Bharat");
		Thread t1=new Thread(md1);
		Thread t2=new Thread(md2);
		md1.start();
		md2.start();
		System.out.println("This is Main Program");
		
	}

}
