package org.anudip.io;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class NumberSorter {
    public static void main(String[] args) throws IOException {
        int[] numbers = new int[9];
        int oddCount = 0, evenCount = 0;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter 9 numbers:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = scanner.nextInt();
            if (numbers[i] % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
        }

        int[] oddNumbers = new int[oddCount];
        int[] evenNumbers = new int[evenCount];

        oddCount = 0;
        evenCount = 0;

        for (int num : numbers) {
            if (num % 2 == 0) {
                evenNumbers[evenCount++] = num;
            } else {
                oddNumbers[oddCount++] = num;
            }
        }

        Arrays.sort(oddNumbers);
        Arrays.sort(evenNumbers);

        writeToFile("odd.txt", oddNumbers);
        writeToFile("even.txt", evenNumbers);

        System.out.println("Odd numbers in ascending order:");
        for (int num : oddNumbers) {
            System.out.println(num);
        }

        System.out.println("Even numbers in ascending order:");
        for (int num : evenNumbers) {
            System.out.println(num);
        }

        scanner.close();
    }

    private static void writeToFile(String filename, int[] numbers) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (int num : numbers) {
                writer.write(Integer.toString(num));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to " + filename + ": " + e.getMessage());
            throw e; // Re-throw the exception to handle it further if needed
        }
    }
}
