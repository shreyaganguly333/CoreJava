package org.anudip.io;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class SortingNumber {
    public static void main(String[] args) throws IOException {
        int[] numbers = new int[9];
        int oddCount = 0, evenCount = 0;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter 9 Single Digit Numbers:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = scanner.nextInt();
            if (numbers[i] % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
        }

        int[] oddNumbers = new int[oddCount];
        int[] evenNumbers = new int[evenCount];

        oddCount = 0;
        evenCount = 0;

        for (int num : numbers) {
            if (num % 2 == 0) {
                evenNumbers[evenCount++] = num;
            } else {
                oddNumbers[oddCount++] = num;
            }
        }

        Arrays.sort(oddNumbers);
        Arrays.sort(evenNumbers);

        writeToFile("d:/odd.txt", oddNumbers);
        writeToFile("d:/even.txt", evenNumbers);

        System.out.println("Numbers written to files successfully.");

        scanner.close();
    }

    private static void writeToFile(String filename, int[] numbers) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (int num : numbers) {
                writer.write(Integer.toString(num));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to " + filename + ": " + e.getMessage());
            throw e; // Re-throw the exception to handle it further if needed
        }
    }
}
