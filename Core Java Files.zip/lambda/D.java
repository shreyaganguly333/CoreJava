package org.anudip.lambda;

public interface D {
	public void show();
	public void disp();
	//public void putData();

}