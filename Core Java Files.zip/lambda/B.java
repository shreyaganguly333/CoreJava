package org.anudip.lambda;

public class B extends A{
	public void display() {
	System.out.println("hi");
	}
	public void putData() {
		System.out.println("ta ta");
		}
}