package org.anudip.lambda;
@FunctionalInterface
public interface AdditionFaceApp {
    public int add(int x,int y);
    
}