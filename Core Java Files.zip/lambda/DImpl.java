package org.anudip.lambda;

public class DImpl implements D {
	
	public void show() {
		System.out.println("Hello world");
	}

	public void disp() {
		System.out.println("Hi world");
	}

	public void putData() {
		System.out.println("Hello hi");
	}

}