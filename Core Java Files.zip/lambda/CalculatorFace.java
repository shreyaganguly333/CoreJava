package org.anudip.lambda;

@FunctionalInterface
public interface CalculatorFace {
	public int calculate(int x, int y, String op);

}