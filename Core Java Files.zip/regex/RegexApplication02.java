package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexApplication02 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		//Input from user
        System.out.print("Enter an email ID: ");
        String email = scanner.nextLine();
        
        //Regex Operation
        String pattern = "^[A-Za-z0-9._%+-]+@gmail\\.com$";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(email);
        
        //Looping and Printing
        if (matcher.matches()) {
            System.out.println("This is a Gmail ID.");
        } else {
            System.out.println("This is not a Gmail ID.");
        }
    }
}