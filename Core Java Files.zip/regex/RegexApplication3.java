package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexApplication3 {

	public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			
			//Input from user
	        System.out.print("Hi Employee! Enter your date of joining in dd-mm-yyyy format: ");
	        String input = scanner.nextLine();
	        
	        //Regex operation
	        String pattern = "^(0[1-9]|1[0-9]|2[0-8])-(0[1-9]|1[0-2])-(\\d{4})$";
	        Pattern regex = Pattern.compile(pattern);
	        Matcher matcher = regex.matcher(input);
	        
	        //looping
	        if (matcher.matches()) {
	            int day = Integer.parseInt(matcher.group(1));
	            int month = Integer.parseInt(matcher.group(2));
	            int year = Integer.parseInt(matcher.group(3));
	            
	        //printing output
	            System.out.println("Date of Joining: " + input);
	            System.out.println("Day: " + day);
	            System.out.println("Month: " + month);
	            System.out.println("Year: " + year);
	        } else {
	            System.out.println("Invalid date format!");
	        }
	    }
	}
	