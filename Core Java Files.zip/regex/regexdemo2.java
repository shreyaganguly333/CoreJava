package org.anudip.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regexdemo2 {

	public static void main(String[] args) {
		Pattern p1=Pattern.compile("[a-z]{1,}s");
		String s1="this";
		String s2="bus";
		
		Matcher m1=p1.matcher(s1);
		System.out.println(m1.matches());
		
		Matcher m2=p1.matcher(s2);
		System.out.println(m2.matches());
		
		//Matcher m3=p1.matcher(s2);
		//System.out.println(m3.matches());
		
	}

}
