package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexApplication1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Input from User
		System.out.print("Enter a name: ");
        String input = sc.nextLine();
        
        //Deciding on Mr/Mrs/Miss
        String pattern = "(Mr\\.|Mrs\\.|Miss\\.)\\s([A-Za-z]+)";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(input);
        
        //Looping
        if (matcher.matches()) {
            String prefix = matcher.group(1);
            String name = matcher.group(2);
            
         //Output printing
            System.out.println("Name: " + name);
            System.out.println("Prefix: " + prefix);
        } else {
            System.out.println("Invalid name format!");
        }
    }
}