package flower;

import java.util.Scanner;

public class GradingSystem {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the Student's Marks Percentages"); //Input for User
	double percentage = scanner.nextDouble();
	
	String grade="";
	if(percentage>89) { //Output for Grade E
		grade="E";
	}else if(percentage>74) { //Output for Grade V
		grade="V";
	}else if(percentage>59) { //Output for Grade G
		grade="G";
	}else if(percentage>50) { //Output for Grade P
		grade="P";
	}else {
		grade="F";	//Output for Grade P
	}
	System.out.println("Final Student's Grade is "+grade); //Final Output

	}

}
