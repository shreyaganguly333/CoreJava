package flower;

public class Book {
	Integer bookNumber;
	String bookName;
	String auther;
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(Integer bookNumber, String bookName, String auther) {
		super();
		this.bookNumber = bookNumber;
		this.bookName = bookName;
		this.auther = auther;
	}
	

}