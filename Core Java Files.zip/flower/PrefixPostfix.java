package flower;

public class PrefixPostfix {

	public static void main(String[] args) {
		int i=5;
		int j=5;
		System.out.println(++i);
		System.out.println(i);
		System.out.println(j++);
		System.out.println(j);
		

	}

}
