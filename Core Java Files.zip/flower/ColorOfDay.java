package flower;

import java.util.Scanner;

public class ColorOfDay {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Color Name:");
		String colorName=sc.nextLine();
		switch(colorName) {
		case "White" : System.out.println("Color of Monday"); break;
		case "Red" : System.out.println("Color of Tuesday"); break;
		case "Green" : System.out.println("Color of Wednesday"); break;
		case "Yellow" : System.out.println("Color of Thursday"); break;
		case "Pink" : System.out.println("Color of Friday"); break;
		case "Black" : System.out.println("Color of Saturday"); break;
		case "Magenta" : System.out.println("Color of Sunday"); break;
		default:System.out.println("Sorry No day is assigned to this color");
		}
		System.out.println("Program is Terminated");
	}

}
