package flower;

public class FlowerView {

	public static void main(String[] args) {
		Rose.show();

	}

}
