package flower;

import java.util.Scanner;

public class OddEven {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any Number of your Choice:");//input of any number 
		int x=sc.nextInt();
		if(x%2==0) {
			System.out.println(x+" is an Even Number");//even number choice
		}
		else {
			System.out.println(x+" is an Odd Number");//odd number choice
		}
	}

	}

