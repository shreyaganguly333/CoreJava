package flower;

public class StrictlyAND {

	public static void main(String[] args) {
		int i=10;
		int j=20;
		if(++i<5 & ++j<15)
			System.out.println("Hello");
		else
			System.out.println("Hi");
		System.out.println("The Value of i:"+i);
		System.out.println("The Value of j:"+j);

	}

}
