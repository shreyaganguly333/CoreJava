package flower;

public class WelcomeEclipse {

	public static void main(String[] args) {
		System.out.println("Welcome to Java and Eclipse");
		System.out.println("Hello Everybody! Happy Ulto Rath");
	}

}
