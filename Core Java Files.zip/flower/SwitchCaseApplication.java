package flower;

import java.util.Scanner;

public class SwitchCaseApplication {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter First Number");
	int m= Integer.parseInt(sc.nextLine());
	System.out.println("Enter Second Number");
	int n= Integer.parseInt(sc.nextLine());
	System.out.println("Enter the Math Operator");
	String Operator= sc.nextLine();
	int result=0;
	switch(Operator) {
	case "Addition(+)": result =(m+n);break;
	case "23": result =(m-n);break;
	case "Division(/)": result = (m/n);break;
	case "Modular(%)": result = (m%+n);break;
	case "Multiplication(*)": result = (m*n);break;
	case "Increment Operator(++)": result = m++; break;
	case "Increment1 Operator(++)": result = n++; break;
	case "Decrement Operator(--)": result = m--;
	case "Decrement1 Operator(++)": result = n--; break;
	default:System.out.println("Wrong Math Operator");
	}
	System.out.println("The Result is "+result);

	}

}
