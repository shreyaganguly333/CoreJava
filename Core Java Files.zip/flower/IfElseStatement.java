package flower;

import java.util.Scanner;

public class IfElseStatement {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number:");
		int x=sc.nextInt();
		if(x>0) {
			System.out.println("Poitive Number");
		}
		else if(x<0){
				System.out.println("Negative Number");
		}
		else {
				System.out.println("It is o, neither positive nor negative");
		}
	}

}
