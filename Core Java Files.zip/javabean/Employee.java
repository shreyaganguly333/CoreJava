package org.anudip.javabean;

public class Employee {
	private Integer employeeId;
	private String employeeName;
	private String DeptName;
	private Double Salary;
	private static int idGenerator=100;
	
	public Employee() {
		super();
		this.employeeId=++idGenerator;
		this.employeeName=employeeName;
		this.DeptName=DeptName;
		this.Salary=Salary;
		
	}
	public Employee(String employeeName, String deptName, Double salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		DeptName = deptName;
		Salary = salary;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDeptName() {
		return DeptName;
	}
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}
	public Double getSalary() {
		return Salary;
	}
	public void setSalary(Double salary) {
		Salary = salary;
	}
	@Override
	public String toString() {
		String output=String.format("%-5s %-15s %-10s %-10s",employeeId,employeeName,DeptName,Salary);
		return  output;
		
	}
	
	
	
	
}
