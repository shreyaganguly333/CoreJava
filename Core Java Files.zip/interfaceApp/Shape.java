package org.anudip.interfaceApp;


	// Shape interface
	public interface Shape {
	    // Member functions
	    public String perimeter();
	    public String area();
	}


