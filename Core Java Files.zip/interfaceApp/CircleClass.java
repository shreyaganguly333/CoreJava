package org.anudip.interfaceApp;
import java.text.DecimalFormat;
import java.util.Scanner;

public class CircleClass implements Shape {
    // Member data
    private double pi = 3.1416;
    private double radius;

    // Constructor
    public CircleClass(double radius) {
        this.radius = radius;
    }

    // Member functions
    public String perimeter() {
        double result = 2 * pi * radius;
        return formatDecimal(result);
    }

    public String area() {
        double result = pi * radius * radius;
        return formatDecimal(result);
    }

    // Helper method to format decimal places to 2
    private String formatDecimal(double value) {
        DecimalFormat df = new DecimalFormat("#.00");
        return df.format(value);
    }

    
}
