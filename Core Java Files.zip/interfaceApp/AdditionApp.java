package org.anudip.interfaceApp;

import java.util.Scanner;

public class AdditionApp {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		AdditionFaceApp af=(x,y)->{
			return x+y;
		};//end of lambda
		System.out.println("Enter first Operand");
		int i=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Second Operand");
		int j=Integer.parseInt(scanner.nextLine());
		int r=af.add(i, j);
		System.out.println("The Result "+r);
	}

}
