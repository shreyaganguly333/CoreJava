package org.anudip.interfaceApp;

public class DemoFaceImpl implements DemoFace {

	@Override
	public void show() {
		System.out.println("Hello Everybody");
		
	}

	@Override
	public void display() {
		System.out.println("Hi Everybody");

	}
	public void putdata() {
		System.out.println("Hello, Hi");
	}
}