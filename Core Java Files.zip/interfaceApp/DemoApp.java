package org.anudip.interfaceApp;

public class DemoApp {

	public static void main(String[] args) {
		DemoFaceImpl df=new DemoFaceImpl();
		df.show();
		df.display();
		df.putdata();

	}

}
