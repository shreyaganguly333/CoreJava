package org.anudip.interfaceApp;

import java.util.Scanner;

public class CircleMain {

	public static void main(String[] args) {
		  Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the radius of the circle: ");
	        double radius = scanner.nextDouble();

	        CircleClass circle = new CircleClass(radius);
	        System.out.println("Circle Perimeter: " + circle.perimeter());
	        System.out.println("Circle Area: " + circle.area());

	        scanner.close();
	    

	}

}
