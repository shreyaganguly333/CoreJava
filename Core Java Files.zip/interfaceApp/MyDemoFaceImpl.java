package org.anudip.interfaceApp;

public class MyDemoFaceImpl implements MyDemoFace {

	@Override
	public void show() {
		System.out.println("Hi People");

	}
	public void dispMessage() {
		System.out.println("Good Day People");
	}
}
