package org.anudip.interfaceApp;
@FunctionalInterface
public interface MyFace {
	public String showMessage(String stg);
	//public String dispMessage();
}
