package org.anudip.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.anudip.application.Voter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class VoterTest {

	@ParameterizedTest
	@CsvSource(value= {"19,true","21,true","15,false","13,false","18,true","17,false"})
	void testValidVoterCheck(int age,boolean expected) {
		Voter voter=new Voter();
		assertEquals(expected,voter.validVoterCheck(age));
	}

}
