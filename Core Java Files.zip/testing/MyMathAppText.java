package org.anudip.testing;

import static org.junit.jupiter.api.Assertions.*;
import org.anudip.application.MyMathApp;
import org.anudip.application.OperatorException;
import org.junit.jupiter.api.Test;

class MyMathAppText {

	@Test
	void testAddition() {
		int p=20;
		int q=30;
		int expected=50;
		int actual=new MyMathApp().addition(p, q);
		assertEquals(expected,actual);
	}

	@Test
	void testMultiply() {
		int p=30;
		int q=2;
		String r="?";
		MyMathApp myMath=new MyMathApp();
		assertThrows(OperatorException.class, ()->myMath.multiply(p, q, r));
	}

	@Test
	void testDivision1() {
		String p="30";
		String q="5";
		int expected=6;
		int actual=new MyMathApp().division(p, q);
		assertEquals(expected,actual);
	}
	@Test
	void testDivision2() {
		String p="30";
		String q="0";
		MyMathApp myMath=new MyMathApp();
		assertThrows(ArithmeticException.class, ()->myMath.division(p, q));
	}
	@Test
	void testDivision3() {
		String p="30";
		String q="a";
		MyMathApp myMath=new MyMathApp();
		assertThrows(NumberFormatException.class, ()->myMath.division(p, q));
	}
}


