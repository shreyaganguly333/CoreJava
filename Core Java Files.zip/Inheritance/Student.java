package Inheritance;

//Child Class
class Student extends Person {
    String grade;

    public Student(String name, int age, String grade) {
        super(name, age);
        this.grade = grade;
    }

    public void study() {
        System.out.println(name + " is studying BTech with an aggregate grade " + grade + ".");
    }
}