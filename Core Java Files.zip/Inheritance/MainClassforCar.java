package Inheritance;

public class MainClassforCar {

		    public static void main(String[] args) {
	        // Creating an object of the Car class
	        Car myCar = new Car("Hyundai", "Elantra", 2022, "Black");

	        // Calling the "drive" method of the Car class (inherited from the parent class)
	        myCar.drive();

	        // Calling the "honk" method of the Car class
	        myCar.honk();
	    }
	}


