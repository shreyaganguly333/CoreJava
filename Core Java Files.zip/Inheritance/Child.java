package Inheritance;

public class Child extends Parent{
	private double j;
	public Child() {
		j=3.75;
		System.out.println("Child Constuctor");
	}
	public void display() {
		System.out.println("The value of j is"+j);
	}

}
