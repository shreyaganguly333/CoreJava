package Inheritance;

public class MainClassforPerson {

		    public static void main(String[] args) {
	        // Creating an object of the Student class
	        Student student = new Student("Shreya", 22, "E");

	        // Calling the "speak" method of the Student class (inherited from the parent class)
	        student.speak();

	        // Calling the "study" method of the Student class
	        student.study();
	    }
	}