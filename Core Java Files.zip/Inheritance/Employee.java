package Inheritance;

import java.util.Scanner;

public class Employee {
	private Integer employeeId;
	private String employeeName;
	private String deptName;
	
	public Employee() {
		this.employeeId=0;
		this.employeeName=" ";
		this.deptName=" ";
	}
	public void getdata() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Employee Id: ");
		employeeId=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Employee Name: ");
		employeeName=scanner.nextLine();
		System.out.println("Enter Department Name: ");
		deptName=scanner.nextLine();
		//scanner.close();
	}
	public void Showdata() {
		System.out.println("The Employee Id is: "+employeeId);
		System.out.println("The Employee Name is: "+employeeName);
		System.out.println("The Department Name is: "+deptName);
	}
	public void taxCalculation() {
	}
}

