package Inheritance;

import java.util.Scanner;

public class PermanentEmployee extends Employee{
	private double monthlySalary;
	public PermanentEmployee() {
		monthlySalary=0.0;
	}
	
	public void getdata() {
		super.getdata();
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter Employee Monthly Salary: ");
	monthlySalary=Double.parseDouble(scanner.nextLine());
	//scanner.close();
	}
	public void Showdata() {
		super.Showdata();
		System.out.println("The Employee Monthly Salary is: "+monthlySalary);
		}
	public void taxCalculation() {
		double annualSalary=monthlySalary*12;
		double taxAmount=annualSalary*0.1;
		System.out.println("The Tax Value is "+taxAmount);
	}
}
