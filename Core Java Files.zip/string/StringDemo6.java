package org.anudip.string;

public class StringDemo6 {

	public static void main(String[] args) {
		String str="Marry Ann Jones";
		String []arr=str.split(" ");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		
	}

}
