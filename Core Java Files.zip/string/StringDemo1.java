package org.anudip.string;

public class StringDemo1 {

	public static void main(String[] args) {
		String str="ABC";
		System.out.println("The Value of String is "+str);
		String stg=str;
		System.out.println("The Value of String is "+stg);
		str=str+"DEF";
		System.out.println("The Value of String is "+str);
		System.out.println("The Value of String is "+stg);
	}

}
