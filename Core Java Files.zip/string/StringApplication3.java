package org.anudip.string;

import java.util.Scanner;

public class StringApplication3 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a Name of a Person");
		String pname=scanner.nextLine();
		String []arr=pname.split(" ");
		if(arr.length==3) {
			System.out.println("The First Name is"+arr[0]);
			System.out.println("The Middle Name is"+arr[1]);
			System.out.println("The Last Name is"+arr[2]);
		}
		else
		{
			System.out.println("The First Name is"+arr[0]);
			System.out.println("The Sur Name is"+arr[1]);
	}

}
}