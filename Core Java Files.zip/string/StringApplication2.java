package org.anudip.string;

import java.util.Scanner;

public class StringApplication2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String str=sc.nextLine();
		System.out.println("Enter the Number from where you'd like to show");
		int a=sc.nextInt();
		System.out.println("Enter the Number upto which you'd like to show");
		int b=sc.nextInt();
		String sub=str.substring(a-1,b+1);
			System.out.println(sub);
		
		
	}

}
