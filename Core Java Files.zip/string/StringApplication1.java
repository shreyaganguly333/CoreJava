package org.anudip.string;

import java.util.Scanner;

public class StringApplication1 {

	public static void main(String[] args) {
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter your Name with Proper Salutation MR/Mrs/Miss");
			String name= scanner.nextLine();
			
			String greeting;
			if(name.startsWith("Mr.")) {
				greeting = "Good Afternoon Sir ";
			} else if(name.startsWith("Mrs.")|| name.startsWith("Miss.")) {
				greeting = "Good Afternoon Maam ";
			} else {
				greeting = "Good Afternoon";
			}
			System.out.println(greeting+name);
	}

}
