package org.anudip.string;

import java.util.Scanner;

public class StringBufferDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Word");
		String myWord=sc.nextLine();
		StringBuffer sb=new StringBuffer(myWord);
		sb.reverse();
		String rword=sb.toString();
		System.out.println(rword);

	}

}
