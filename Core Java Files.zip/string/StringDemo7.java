package org.anudip.string;

import java.util.Scanner;

public class StringDemo7 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Name of a Person");
		String pname=scanner.nextLine();
		if(pname.endsWith("a")||pname.endsWith("i"))
			System.out.println("Name of a Girl");
		else {
			System.out.println("Name of a Boy");
		}
	}

}
