package org.anudip.string;

public class StringDemo3 {

	public static void main(String[] args) {
		String str="ABCDEFGH";
		//CHARAT FUNCTION
		/*char ch1=str.charAt(0);
		System.out.println(ch1);
		char ch2=str.charAt(1);
		System.out.println(ch2);*/
		
		System.out.println("The Length of Str "+str.length());
		for(int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			System.out.println(ch);
		}
		//TRIMING FUNCTION
		String stg= "  XYZPQR   ";
		stg=stg.trim();
		System.out.println("The Length of Str "+stg.length());
	}
}

