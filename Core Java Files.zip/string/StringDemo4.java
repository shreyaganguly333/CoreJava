package org.anudip.string;

import java.util.Scanner;

public class StringDemo4 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a Sentence");
		String str=scanner.nextLine();
		String []arr=str.split(" ");
		System.out.println("The No of Words in the Sentence is"+arr.length);
		for(String s:arr) {
			System.out.println(s);
		}
	}

}
