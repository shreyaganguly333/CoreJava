package org.anudip.string;

import java.util.Scanner;

public class StringBufferApplicationPalindrome {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Word");
		String nWord=sc.nextLine();
		StringBuffer sb=new StringBuffer(nWord);
		sb.reverse();
		String rword=sb.toString();
		if (nWord.equalsIgnoreCase(rword))
			{System.out.println(nWord+ " is a Palindrome");
		}
		else
			System.out.println(nWord+ "not a Palindrome");

	}

}
