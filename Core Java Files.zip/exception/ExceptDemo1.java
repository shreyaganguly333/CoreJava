package org.anudip.exception;

import java.util.Scanner;

public class ExceptDemo1 {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		try {
		System.out.println("Enter Numerator");
		int n=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Divisor");
		int d=Integer.parseInt(scanner.nextLine());
		int r=n/d;
		System.out.println("The Result is "+r);
		int [] arr= {10,20,30,40,50};
		System.out.println(arr[6]);
		scanner.close();
		}//end of try
		catch(ArithmeticException ae) {
			System.out.println("Dividing by Zero Impossible");
		}//end of catch
		catch(NumberFormatException ne) {
			System.out.println("Input must be a Whole Number");
		}//end of catch
		catch(Exception ex) {
			System.out.println("Some Error......");
		}
		finally {
			System.out.println("The Application is Over");
		}

	}
}
