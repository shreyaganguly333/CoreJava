package org.anudip.exception;

import java.util.Scanner;

public class MainClassOld {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            System.out.print("Hi User! Please Enter your Age: ");
            int age = scanner.nextInt();
            checkAgeValidity(age);
            checkVoterEligibility(age);
            System.out.println("Congrats! Your Age and voter eligibility are valid.");
        } catch (AgeException | VoterException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static void checkAgeValidity(int age) throws AgeException {
          	if (age < 1 || age > 150) {
            throw new AgeException("Uh no! Invalid age. Age should be between 1 and 150.");
        }
        
    }

    private static void checkVoterEligibility(int age) throws VoterException {
        if (age < 18) {
            throw new VoterException("Invalid age for enrollment as a voter. Minimum age should be 18.");
        }
    }
}
