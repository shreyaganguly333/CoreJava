package fruit;

import java.util.Scanner;

public class TaxCalculation {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the Name of the Employee");
	String name =scanner.nextLine();
	System.out.println("Enter the Annual Salary");
	double salary = Double.parseDouble(scanner.nextLine());
	double tax = 0;
	if (salary<=250000) {
		tax =0;
	}
	else if (salary <=1000000) {
		tax= ((salary-500000)*0.2)+30000;
	}
	else {
		tax= ((salary-1000000)*0.3)+30000;
	}
	System.out.println("Name of the Employee is "+name);
	System.out.println("Employee Tax is "+tax);
	}
				
	}