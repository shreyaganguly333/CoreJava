package fruit;

public class DataTypeApplication {

	public static void main(String[] args) {
		String ss="20";
		String rr="40";
		String pp=ss+rr;
		System.out.println(pp);
		int x=Integer.parseInt(ss);
		int y=Integer.parseInt(rr);
		int z=x+y;
		System.out.println(z);
	}

}
