package fruit;

import java.util.Scanner;

//import java.util.Scanner;

public class JavaTask {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Radius");
		double radius=sc.nextDouble();
		double perimeter=3.1416*radius*radius;
		double area=2*3.1416*radius;
		System.out.println("The area of the circle is"+perimeter);
		System.out.println("Enter the Area"+area);
		
	}

}
