package fruit;

import java.util.Scanner;

public class NewTask {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID");
		int id=Integer.parseInt(sc.nextLine());
		System.out.println("Enter Employee Name");
		String name=sc.nextLine();
		System.out.println("Enter Employee Salary");
		double salary=sc.nextDouble();
		System.out.println("The Employee Id is:" +id);		
		System.out.println("The Employee Name is:" +name);
		System.out.println("The Employee Salary is:" +salary);
	}

}
