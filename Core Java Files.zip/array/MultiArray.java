package org.anudip.array;

import java.util.Scanner;

public class MultiArray {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int [][] arr= {{20,30,40,50},{25,35,45,55},{60,70,80,90}};
		for(int row=0;row<3;row++) {
			System.out.println();
			for(int col=0;col<4;col++) {
				System.out.print(arr[row][col]+" "); 
			}
		}
	}

}


