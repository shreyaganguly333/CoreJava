package org.anudip.array;

import java.util.Arrays;

public class ArrayDemo2 {

	public static void main(String[] args) {
		int []arr = {60,23,57,89,25,54,11,92,73,49};
		System.out.println("What is the size of the Array? "+arr.length);
		System.out.println("Display");
		boolean flag=false;
		for (int i=0;i<arr.length;i++) {
				System.out.println(arr[i]);
		}
		Arrays.sort(arr);
		System.out.println("Display after Sorting");
		
		for (int i=0;i<10;i++) {
			System.out.println(arr[i]);
		}
		System.out.println("In descending order");
		for (int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
		}
	}
}

