package org.anudip.array;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Hi User! Please give the Number to display the Fibonacci Series");//Input from User
		int count = sc.nextInt();
		
		int first = 0; //storing input 
        int second = 1; //storing input

        System.out.println("Fibonacci series values:"); //output of fibonacci
        for (int i = 1; i <= count; i++) { //calculations
            System.out.print(first + " "); //display of the series

            int next = first + second;
            first = second;
            second = next;
		}
	}

}
