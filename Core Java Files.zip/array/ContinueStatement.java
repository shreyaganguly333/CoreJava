package org.anudip.array;

import java.util.Scanner;

public class ContinueStatement {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		int counter=0;
		while(counter<5) {
			System.out.println("Enter an Even Statement");
			int p=scanner.nextInt();
			if(p%2!=0)
				continue;
			
				int q=p/2;
				System.out.println("The half of p"+p+ "="+q);
				counter++;
				
		}
		

	}

}
