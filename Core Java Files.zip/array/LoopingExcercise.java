package org.anudip.array;

import java.util.Scanner;

public class LoopingExcercise {

	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Hi User! Please give a Number");//Input from User
	int num = sc.nextInt();
	
	long factorial = 1; //defining factorial
	for (int i = 2; i <= num; i++) //calculations
    factorial *= i;
    System.out.println("The Factorial of the Number is " +factorial); //printing output
	}
}


