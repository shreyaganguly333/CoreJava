package org.anudip.array;

public class LoopDemo {

	public static void main(String[] args) {
		int counter = 10;
		while(counter<5) {
				System.out.println("Hello");
				counter++;
		}
		System.out.println("We are outside the Loop");

	}

}
