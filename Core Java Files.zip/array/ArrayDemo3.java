package org.anudip.array;

import java.util.Scanner;
import java.util.Arrays;

public class ArrayDemo3 {

	public static void main(String[] args) {
		int []arr = {60,80,100,20,70,10,40,90,50,30};
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter a number and check whether it is present in the array and mention it's location");
		int n=scanner.nextInt();
		boolean flag=false;
		for (int i=0;i<arr.length;i++) {
			if (arr[i]==n) {
				System.out.println("The Value present in the location:" +(i+1));
				flag=true;
				break;
		}
		}
		if(!flag) {
				System.out.println("This data is not present in the array");
	}
}
}
