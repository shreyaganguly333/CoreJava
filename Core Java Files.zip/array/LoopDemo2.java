package org.anudip.array;

public class LoopDemo2 {

	public static void main(String[] args) {
		int counter = 0;
		do {
				System.out.println("Hello");
				counter++;
		}while(counter<5);
		System.out.println("We are outside the Loop");

	}

}
