package org.anudip.application;

import java.text.DecimalFormat;
import java.util.Scanner;

public class CircleApp {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter radius of a circle:");
		double radius=Double.parseDouble(scanner.nextLine());
		Circle circle=new Circle(radius);
		double perimeter=circle.perimeterCalculation();
		double area=circle.areaCalculation();
		DecimalFormat myFormat=new DecimalFormat("0.00");
		String perimeterStr=myFormat.format(perimeter);
		String areaStr=myFormat.format(area);		
		System.out.println("Perimeter:"+perimeterStr);
		System.out.println("Area:"+areaStr);
		scanner.close();
	}

}
