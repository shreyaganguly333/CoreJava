package org.anudip.application;
import java.util.Scanner;
import org.anudip.javabean.Student;
import org.anudip.services.StudentService;
public class StudentArrayMain2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//ask the number of studen's record to store
		System.out.println("Enter the number of students:");
		int number = Integer.parseInt(scanner.nextLine());
		
		
		//array declaration
		Student [] studArr = new Student[number];
		//within loop any number of student details are accepted & stored in array
		for(int index=0;index<studArr.length;index++) {
			//to get output in this below print format
			int j = index+1;
			System.out.println("Enter Student no "+j+". details in (roll,name,course,marks) format:");
			//Accept student details
		System.out.println("Enter Student roll: ");
		int roll = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Student name: ");
		String name = scanner.nextLine();
		System.out.println("Enter Student course: ");
		String course = scanner.nextLine();
		System.out.println("Enter Student marks: ");
		double marks = Double.parseDouble(scanner.nextLine());
		
		Student student = new Student(roll,name,course,marks);
		String grade = StudentService.calculateGrade(student);
		student.setStudentGrade(grade); //setter method of grade
		studArr[index] = student;
		}//end of for loop
		String headings = String.format("%-5s %-15s %-10s %-5s %-5s","Roll","Name","Course","Marks","Grade");
		System.out.println(headings);//to add heading to the bar chart output
		//display all students records from array
		for(Student std:studArr) {
			System.out.println(std);
		}
		

	}

}