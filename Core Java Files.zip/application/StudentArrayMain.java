package org.anudip.application;
import java.util.Scanner;
import org.anudip.javabean.Student;
import org.anudip.services.StudentService;
public class StudentArrayMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//array declaration
		Student [] studArr = new Student[3];
		//within loop 3 student details are accepted & stored in array
		for(int index=0;index<studArr.length;index++) {
		//Accept student details
		
		System.out.println("Enter Student roll: ");
		int roll = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Student name: ");
		String name = scanner.nextLine();
		System.out.println("Enter Student course: ");
		String course = scanner.nextLine();
		System.out.println("Enter Student marks: ");
		double marks = Double.parseDouble(scanner.nextLine());
		
		Student student = new Student(roll,name,course,marks);
		String grade = StudentService.calculateGrade(student);
		student.setStudentGrade(grade); //setter method of grade
		studArr[index] = student;
		}//end of for loop
		String headings=String.format("%-5s %-15s %-10s %-5s %-5s","Roll","Name","Course","Marks","Grade");
		System.out.println(headings);
		//display all students records from array
		for(Student std:studArr) {
			System.out.println(std);
		}
		

	}

}