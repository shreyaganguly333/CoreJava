package org.anudip.application;

import java.util.Scanner;

import org.anudip.javabean.Student;
import org.anudip.services.StudentService;

public class StudentMain {

	public static void main(String[] args) {
		//Accept student details
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter student details(roll,namecourse,marks)format:");
    String input=scanner.nextLine();
    String[]inputArray=input.split(",");
    int roll= Integer.parseInt(inputArray[0]);
	double marks=Double.parseDouble(inputArray[0]);
	Student student=new Student(roll,inputArray[1],inputArray[2],marks);
	String grades=StudentService.calculateGrade(student);
	student.setStudentGrade(grades);
	System.out.println(student);
	
	}

}