package org.anudip.application;

import org.anudip.javabean.Demo;

public class DemoMain {

	public static void main(String[] args) {
		
		Demo d1=new Demo();
		Demo d2=new Demo();
		d1.display();
		d2.display();
		int x=20;
		double y=27.56;
		Demo d3=new Demo(x,y);
		d3.display();
		Demo d4=new Demo(d3);
		d4.display();
			}
		
		}