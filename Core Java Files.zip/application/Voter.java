package org.anudip.application;

public class Voter {
	public boolean validVoterCheck(int age) {
		if(age>=18)
			return true;
		else
			return false;
	}
}
