package org.anudip.application;

import org.anudip.javabean.Employee;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of Employees Entry");
		int no=Integer.parseInt(sc.nextLine());
		Employee [] empArr=new Employee[no];
		for(int i=0;i<no;i++) {
			System.out.println("Enter Employee Details(name,dept,salary) format:");
			String emp=sc.nextLine();
			String []arr=emp.split(",");
			double salary=Double.parseDouble(arr[2]);
			Employee employee=new Employee((arr[0]),arr[1],salary);
			empArr[i]=employee;
		
		}
		//display
		for(Employee em:empArr) {
			System.out.println(em);
	}

	}
}
