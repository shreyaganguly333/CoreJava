package Assignments;

import java.util.Arrays;
import java.util.Scanner;

public class CollectingSingleCharecters {

	public static void main(String[] args) {
       Scanner scanner=new Scanner(System.in);
       System.out.println("Enter a word");
		String str=scanner.nextLine();
	    String m1=str.toLowerCase();
	    char[]string12=m1.toCharArray();
	        Arrays.sort(string12);
	        int max_count = 0;
	        char max_char=Character.MIN_VALUE;
	        System.out.println("Java program to find non Repeating Characters in assending order");
	        int[] arr = new int[1000];
	        for(int i = 0; i < str.length(); i++){
	        	String m2=m1.toUpperCase();
	            arr[m2.charAt(i)]++; 
	        }
	        System.out.println ("Non Repeating characters are");
	        for (int i = 0; i < 1000; i++)
	        {
	            if (arr[i] == 1)
	            {
	                System.out.println((char)i);
	            }
	        }
	    }
	}