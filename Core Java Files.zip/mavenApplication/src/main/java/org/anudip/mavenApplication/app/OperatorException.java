package org.anudip.mavenApplication.app;

public class OperatorException extends RuntimeException {

}
