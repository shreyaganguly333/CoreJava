package org.anudip.mavenApplication.jdbc;

public class Employee {
	private Integer employeeId;
	private String employeeName;
	private Double basic;
	private Double net;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(Integer employeeId, String employeeName, Double basic, Double net) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.basic = basic;
		this.net = net;
	}
	public Employee(Integer employeeId, String employeeName, Double basic) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.basic = basic;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Double getBasic() {
		return basic;
	}
	public void setBasic(Double basic) {
		this.basic = basic;
	}
	public Double getNet() {
		return net;
	}
	public void setNet(Double net) {
		this.net = net;
	}
	@Override
	public String toString() {
		String output=String.format("%-5s %-15s %-15s %-15s", employeeId,employeeName,basic,net);
		return output;
	}
	
}
