package org.anudip.mavenApplication.collection;

import java.util.LinkedList;
import java.util.Collections;
import java.util.ListIterator;
public class LinkedListDemo1 {

	public static void main(String[] args) {
		LinkedList<String> myList=new LinkedList<String>();
		myList.add("Rose");
		myList.add("Lotus");
		myList.add("Lily");
		myList.add("Marigold");
		myList.add("Jasmine");
		myList.addLast("Lavender");
		myList.add("Cosmos");
		myList.add("Dalia");
		myList.add("Zenia");
		myList.add("Tulip");
		myList.add("Jui");
		myList.addFirst("Sunflower");
		/*System.out.println("Display in the order of entry with for each loop");
		for(String str:myList) {
			System.out.println(str);
			}*/
		ListIterator<String> iterator=myList.listIterator();
		System.out.println("Display in the order of entry from 1st to last with ListIterator");
		while(iterator.hasNext()) {
			String stg=iterator.next();
			System.out.println(stg);
		}
		System.out.println("Display in the order of entry from Last to 1st with ListIterator");
		while(iterator.hasPrevious()) {
			String stg=iterator.previous();
			System.out.println(stg);
		}
		System.out.println("Display in the order of entry with Lambda Expression");
		myList.forEach(str->System.out.println(str));
		
		/*System.out.println("Display in Ascending Order");
		Collections.sort(myList);
		myList.forEach(str->System.out.println(str));


		System.out.println("Display in Descending Order");
		Collections.reverse(myList);
		myList.forEach(str->System.out.println(str));*/

	
	}
}
