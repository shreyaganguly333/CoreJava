package org.anudip.mavenApplication.collection;
import java.util.HashSet;
import java.util.Scanner;
public class HashSetDemo2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number of products to store");
		int no = Integer.parseInt(scanner.nextLine());
		HashSet <Commodity>productSet = new HashSet<Commodity>();
		for(int i = 0; i<no; i++) {
			System.out.println("Enter product details in comma(, ) separated String");
			String stg = scanner.nextLine();
			String[]arr = stg.split(",");
			int id = Integer.parseInt(arr[0]);
			double price = Double.parseDouble(arr[2]);
			Commodity commodity= new Commodity(id,arr[1],price);
			productSet.add(commodity);
			System.out.println("Display");
			productSet.forEach(prod->System.out.println(prod));
		}//end of loop
		
		
	}//end of main
}//end of class