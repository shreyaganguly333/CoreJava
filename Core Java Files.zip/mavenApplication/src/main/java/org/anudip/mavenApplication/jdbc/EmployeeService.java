package org.anudip.mavenApplication.jdbc;

public class EmployeeService {
	public static Employee netCalculation(Employee emp) {
		double basic=emp.getBasic();
		double net=basic+basic*0.15;
		emp.setNet(net);
		return emp;
	}
}
