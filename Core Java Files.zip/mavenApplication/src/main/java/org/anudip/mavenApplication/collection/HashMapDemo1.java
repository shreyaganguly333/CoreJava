package org.anudip.mavenApplication.collection;

import java.util.HashMap;
public class HashMapDemo1 {

	public static void main(String[] args) {
		HashMap<Integer,String> myMap=new HashMap<>();
		myMap.put(103,"Rose");
		myMap.put(105,"Tulip");
		myMap.put(101,"Cosmos");
		myMap.put(104,"Rose");
		myMap.put(102,"Marigold");
		myMap.put(106,"Lotus");
		myMap.put(102,"Lily");
		System.out.println(myMap);
		
	}

}
